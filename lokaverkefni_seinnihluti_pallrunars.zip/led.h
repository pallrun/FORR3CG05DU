//led.h
#pragma once

#include "ihlutir.h"
#include <string>

using namespace std;

class led: public ihlutir {
    private:
        string color;

    public:
        led(int number, int size, string color);
        string getColor();
        void setColor(string color);
        void update() override;
        void display() override;
};