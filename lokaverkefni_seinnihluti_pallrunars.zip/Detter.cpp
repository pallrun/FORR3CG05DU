//Detter.cpp
#include "Detter.h"
#include <iostream>

using namespace std;

detter::detter(int number, int size, double rymd) : ihlutir(number, size) {
    this->rymd = rymd;
}

double detter::getrymd() {
    return rymd;
}

void detter::setrymd(double rymd) {
    this->rymd = rymd;
}

void detter::update() {
    cout << "veldu ihluta numer: ";
    cin >> number;
    cout << "veldu ihluta stærð: ";
    cin >> size;
    cout << "veldu ihluta ohma: ";
    cin >> rymd;
    cout << "ihlutur uppfærður!" << endl;
}

void detter::display() {
    cout << "Þéttir\t" << number << "\t" << size << "\t" << rymd << endl;
}