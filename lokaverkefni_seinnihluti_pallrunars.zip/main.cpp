//main.cpp
#include "ihlutir.h"
#include "vidnam.h"
#include "led.h"
#include "Detter.h"
#include "list.h"
#include <iostream>

using namespace std;

int main() {
    list *list1 = new list();
    int choice;
    int number;
    int size;
    double ohm;
    string color;
    while (true) {
        cout << "1. bæta við viðnami." << endl;
        cout << "2. bæta við LED" << endl;
        cout << "3. bæta við þéttir" << endl;
        cout << "4. eiða ihlut" << endl;
        cout << "5. leita af ihlut" << endl;
        cout << "6. uppfæra ihlut" << endl;
        cout << "7. prenta ut alla ihluti" << endl;
        cout << "8. hætta!" << endl;
        cout << "veldu forrit!: ";
        cin >> choice;
        switch (choice) {
            case 1:
                cout << "veldu ihluts numer: ";
                cin >> number;
                cout << "veldu ihluts stærð: ";
                cin >> size;
                cout << "veldu ihluts Ohma: ";
                cin >> ohm;
                list1->addihlutir(new vidnam(number, size, ohm));
                break;
            case 2:
                cout << "veldu ihluts numer: ";
                cin >> number;
                cout << "veldu ihluts stærð: ";
                cin >> size;
                cout << "veldu ihluts lit: ";
                cin.ignore();
                getline(cin, color);
                list1->addihlutir(new led(number, size, color));
                break;
            case 3:
                cout << "veldi ihluta numer: ";
                cin >> number;
                cout << "veldu ihluta stærð: ";
                cin >> size;
                cout << "veldu ihluta Ohma: ";
                cin >> ohm;
                list1->addihlutir( new detter(number, size, ohm));
                break;
            case 4:
                cout << "veldu ihluta numer: ";
                cin >> number;
                list1->deleteihlutir(number);
                break;
            case 5:
                cout << "veldu ihluta numer: ";
                cin >> number;
                list1->searchihlutir(number)->display();
                break;
            case 6:
                cout << "veldu ihluta numer: ";
                cin >> number;
                list1->updateihlutir(number);
                break;
            case 7:
                list1->display();
                break;
            case 8:
                exit(0);
            default:
                cout << "vitlaust svar" << endl;
        }
    }
    return 0;
}