//list.cpp
#include "list.h"
#include <iostream>

using namespace std;


list::list() {
    head = NULL;
    tail = NULL;
}

void list::addihlutir(ihlutir *component) {
    node *temp = new node;
    temp->component = component;
    temp->next = NULL;
    if (head == NULL) {
        head = temp;
        tail = temp;
        temp = NULL;
    } else {
        node *current = head;
        node *previous = NULL;
        while (current != NULL && current->component->getNumber() < component->getNumber()) {
            previous = current;
            current = current->next;
        }
        if (previous == NULL) {
            temp->next = head;
            head = temp;
        } else {
            temp->next = current;
            previous->next = temp;
        }
    }
}

void list::deleteihlutir(int number) {
    node *current = head;
    node *previous = NULL;
    while (current != NULL && current->component->getNumber() != number) {
        previous = current;
        current = current->next;
    }
    if (current == NULL) {
        cout << "ihlutur ekki til eða ekki funndinn" << endl;
    } else {
        if (previous == NULL) {
            head = head->next;
            delete current;
        } else {
            previous->next = current->next;
            delete current;
        }
    }
}

ihlutir* list::searchihlutir(int number) {
    node *current = head;
    while (current != NULL && current->component->getNumber() != number) {
        current = current->next;
    }
    if (current == NULL) {
        cout << "ihlutir ekki til eða ekki fundnir" << endl;
        return NULL;
    } else {
        return current->component;
    }
}

void list::updateihlutir(int number) {
    node *current = head;
    while (current != NULL && current->component->getNumber() != number) {
        current = current->next;
    }
    if (current == NULL) {
        cout << "ihlutir ekki til til eða fundnir!" << endl;
    } else {
        current->component->update();
    }
}

void list::display() {
    node *current = head;
    cout << "Íhlutur\tNr.\tStærð\tLitur/Ω/F" << endl;
    while (current != NULL) {
        current->component->display();
        current = current->next;
    }
}