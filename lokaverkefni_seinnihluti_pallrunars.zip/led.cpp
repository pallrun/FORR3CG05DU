//led.cpp
#include "led.h"
#include <iostream>

using namespace std;

led::led(int number, int size, string color) : ihlutir(number, size) {
    this->color = color;
}

string led::getColor() {
    return color;
}

void led::setColor(string color) {
    this->color = color;
}

void led::update() {
    cout << "veldu ihluta numer: ";
    cin >> number;
    cout << "veldu ihluta staerd: ";
    cin >> size;
    cout << "veldu ihluta lit: ";
    cin >> color;
    cout << "ihlutur uppfærður!" << endl;
}

void led::display() {
    cout << "LED\t" << number << "\t" << size << "\t" << color << endl;
}