//Detter.h
#pragma once

#include "ihlutir.h"

using namespace std;

class detter: public ihlutir {
    private:
        double rymd;

    public:
        detter(int number, int size, double rymd);
        double getrymd();
        void setrymd(double rymd);
        void update() override;
        void display() override;
};