//vidnam.h
#pragma once

#include "ihlutir.h"

using namespace std;

class vidnam: public ihlutir {
    private:
        double ohm;

    public:
        vidnam(int number, int size, double ohm);
        double getOhm();
        void setOhm(double ohm);
        void update() override;
        void display() override;
};