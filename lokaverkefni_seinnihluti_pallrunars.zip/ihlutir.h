//ihlutir.h
#pragma once

#include <iostream>
#include <string>

class ihlutir {
    protected:
        int number, size;

    public:
        ihlutir(int number, int size);
        int getNumber();
        int getSize();
        void setNumber(int number);
        void setSize(int size);
        void virtual update();
        void virtual display();
};