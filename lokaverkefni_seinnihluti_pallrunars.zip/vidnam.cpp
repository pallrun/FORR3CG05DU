//vidnam.cpp
#include "vidnam.h"
#include <iostream>

vidnam::vidnam(int number, int size, double ohm) : ihlutir(number, size) {
    this->ohm = ohm;
}

double vidnam::getOhm() {
    return ohm;
}

void vidnam::setOhm(double ohm) {
    this->ohm = ohm;
}

void vidnam::update() {
    cout << "veldu ihluta numer: ";
    cin >> number;
    cout << "veldu ihluta staerd: ";
    cin >> size;
    cout << "veldu ihluta Ohma: ";
    cin >> ohm;
    cout << "ihlutur uppfærður!" << endl;
}

void vidnam::display() {
    cout << "Viðnám\t" << number << "\t" << size << "\t" << ohm << endl;
}