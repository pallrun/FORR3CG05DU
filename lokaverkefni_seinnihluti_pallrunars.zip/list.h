//list.h
#pragma once

#include "ihlutir.h"

class node {
    public:
        ihlutir *component;
        node *next;
};

class list {
    private:
        node *head, *tail;
    public:
        list();
        void display();
        void addihlutir(ihlutir *component);
        void deleteihlutir(int number);
        ihlutir* searchihlutir(int number);
        void updateihlutir(int number);

};