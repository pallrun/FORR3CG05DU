//ihlutir.cpp
#include "ihlutir.h"
#include <iostream>

using namespace std;

ihlutir::ihlutir(int number, int size) {
    this->number = number;
    this->size = size;
}

int ihlutir::getNumber() {
    return number;
}

int ihlutir::getSize() {
    return size;
}

void ihlutir::setNumber(int number) {
    this->number = number;
}

void ihlutir::setSize(int size) {
    this->size = size;
}

void ihlutir::update() {
    cout << "veldu ihluta numer: ";
    cin >> number;
    cout << "veldu ihluta stærð: ";
    cin >> size;
    cout << "ihlutur uppfærður" << endl;
}

void ihlutir::display() {
    cout << "ihluta numer: " << number << "\tihluta stærð: " << size << endl;
}